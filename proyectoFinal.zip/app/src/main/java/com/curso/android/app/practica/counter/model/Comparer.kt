package com.curso.android.app.practica.counter.model

data class Comparer(var areTheyEquals: String)




