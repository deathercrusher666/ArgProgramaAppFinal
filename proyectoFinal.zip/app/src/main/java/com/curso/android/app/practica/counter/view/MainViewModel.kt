package com.curso.android.app.practica.counter.view


import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.curso.android.app.practica.counter.model.Comparer
import kotlinx.coroutines.launch

class MainViewModel: ViewModel() {

    // Solo queremos que se pueda leer el contador
    val comparer: LiveData<Comparer> get() = _comparer
    // no nos interesa que se modifique por fuera del ViewModel
    var _comparer = MutableLiveData<Comparer>(Comparer("Aun no se compararon textos"))
/**
    fun incrementCounter() {
        val next = (_counter.value?.number ?: 0) + 1
        updateCounter(next)
    }

    fun decrementCounter() {
        val next = (_counter.value?.number ?: 0) - 1
        updateCounter(next)
    }

    private fun updateCounter(next: Int) {
        viewModelScope.launch {
            _counter.value = Counter(next, Date(),_counter.value.textA,_counter.value.textB)
        }
    }**/

    fun mainComparison(textA: String, textB: String) {
    updateComparison(compareStrings(textA, textB))
    }

    private fun compareStrings(textA: String, textB: String): Boolean {
            return textA == textB
    }

    private fun updateComparison(isEqual: Boolean){
        if(isEqual) {
            println("SON IGUALES")
            viewModelScope.launch { _comparer.value = Comparer("Son iguales") }
        }
        else{
            println("SON DISTINTOS")
            viewModelScope.launch { _comparer.value = Comparer("Son distintos") }
        }
    }

}
